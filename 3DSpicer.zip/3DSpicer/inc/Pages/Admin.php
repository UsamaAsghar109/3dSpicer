<?php
/**
* @package 3D Spicer
*/
namespace Inc\Pages;

use \Inc\Base\BaseController;
use \Inc\Api\SettingsApi;
use Inc\Api\Callbacks\AdminCallbacks;
/**
* 
*/

class Admin extends BaseController{
	public $settings;
	
	public $callbacks;
	
	public $pages = array();
	
	public $subpages = array();
	
	
	public function register() 
	{
		$this->settings = new SettingsApi();
		
		$this->callbacks= new AdminCallbacks();
		
		$this->setPages();
		
		$this->setSubPages();

		$this->setSettings();
		$this->setSections();
		$this->setFields();
		
		$this->settings->addPages( $this->pages )->withSubPage('Dashboard')->addSubPages($this->subpages)->register();
	}
	
	public function setPages(){
		
		$this->pages = array(
			array(
				'page_title' => '3D Spicer', 
				'menu_title' => '3D Spicer', 
				'capability' => 'manage_options', 
				'menu_slug' => 'spicer_plugin', 
				'callback' => array($this->callbacks, 'adminDashboard'), 
				'icon_url' => 'dashicons-store', 
				'position' => 110
				)
				
			);
		}
		
		public function setSubPages(){
			
			$this->subpages=array(
				array(
					'parent_slug' => 'spicer_plugin', 
					'page_title' => 'Integration', 
					'menu_title' => 'Integration', 
					'capability' => 'manage_options',
					'menu_slug' => 'spicer_plugin_integration', 
					'callback' => array($this->callbacks, 'integration'), 
				),
				array(
					'parent_slug' => 'spicer_plugin', 
					'page_title' => 'Contact Us', 
					'menu_title' => 'Contact Us', 
					'capability' => 'manage_options',
					'menu_slug' => 'spicer_plugin_contact_us', 
					'callback' => array($this->callbacks, 'contactUs'), 
				),
				array(
					'parent_slug' => 'spicer_plugin', 
					'page_title' => 'API Key', 
					'menu_title' => 'API Key', 
					'capability' => 'manage_options',
					'menu_slug' => 'spicer_plugin_api_key', 
					'callback' => array($this->callbacks, 'apiKey'), 
					)
				);
				
			}

			public function setSettings(){
				$args=array(
					array(
						'option_group' => 'spicer_options_group',
						'option_name' => 'text_example',
						'callback' => array( $this->callbacks, 'spicerOptionsGroup')
					)
				);

				$this->settings->setSettings($args);
			}

			public function setSections(){
				$args=array(
					array(
						'id' => 'spicer_admin_index',
						'title' => 'Settings',
						'callback' => array( $this->callbacks, 'spicerAdminSection'),
						'page' => 'spicer_plugin'
					)
				);

				$this->settings->setSections($args);
			}

			public function setFields(){
				$args=array(
					array(
						'id' => 'text_example',
						'title' => 'Text Example',
						'callback' => array( $this->callbacks, 'spicerTextExample'),
						'page' => 'spicer_plugin',
						'section' => 'spicer_admin_index',
						'args' => array(
							'label-for' => 'text_example',
							'class' => 'example-class'
						)
					)
				);

				$this->settings->setFields($args);
			}
			
		}
		
		// public function register(){
			// 	add_action( 'admin_menu', array( $this, 'add_admin_pages' ) );
			// } 
			
			// public function add_admin_pages() {
				// 	add_menu_page( '3D Spicer Plugin', '3D Spicer', 'manage_options', 'spicer_plugin', array( $this, 'admin_index' ), 'dashicons-store', 110 );
				// }
				
				// public function admin_index() {
					// 	require_once $this->plugin_path . 'templates/admin.php';
					// }