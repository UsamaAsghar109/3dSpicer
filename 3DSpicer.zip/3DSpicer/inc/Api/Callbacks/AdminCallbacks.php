<?php
/**
 * @package 3D Spicer
 */
namespace Inc\Api\Callbacks ;

use \Inc\Base\BaseController;
/**
 * 
 */

class AdminCallbacks extends BaseController{

    public function adminDashboard(){
        return require_once("$this->plugin_path/templates/admin.php"); 
    }

    public function integration(){
        return require_once("$this->plugin_path/templates/integration.php"); 
    }

    public function contactUs(){
        return require_once("$this->plugin_path/templates/contactUs.php"); 
    }

    public function apiKey(){
        return require_once("$this->plugin_path/templates/apiKey.php"); 
    }

    public function spicerOptionsGroup($input){

        return $input;

    }

    public function spicerAdminSection(){

        echo 'Check the section';

    }

    public function spicerTextExample(){

        $value= esc_attr( get_option('text_example') );
        echo '<input type="text" clas="regular-text" name="text_example" value="'.$value.'" placeholder="Write something here..."/>';
    }

}